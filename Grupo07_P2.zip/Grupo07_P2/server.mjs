import https from 'https';
import fs from 'fs';
import express from 'express';
import { Server } from 'socket.io';
import path from 'path';

// Configurar las opciones de HTTPS (certificado y clave privada)
const options = {
    key: fs.readFileSync('certificados/MiServidorHTTPS.key'),
    cert: fs.readFileSync('certificados/MiServidorHTTPS.crt'),
};

const app = express();

// Middleware para analizar JSON
app.use(express.json());

// Configurar Express para servir archivos estáticos desde la carpeta 'public'
app.use(express.static('public'));

// Endpoint para servir las páginas
app.get('/', (req, res) => {
  res.sendFile('login.html', { root: 'public' });
});

app.get('/menu', (req, res) => {
  res.sendFile('map.html', { root: 'public' });
});

app.get('/ratings', (req, res) => {
  res.sendFile('ratings.html', { root: 'public' });
});

app.get('/incidences', (req, res) => {
  res.sendFile('incidences.html', { root: 'public' });
});


// Endpoint para guardar valoraciones
app.post('/ratings', (req, res) => {
  const rating = req.body;

  if (!rating.usuario || !rating.estrellas || !rating.fecha) {
    return res.status(400).send({ error: "Faltan datos obligatorios en la valoración." });
  }

  // Leer las valoraciones actuales
  const valoraciones = leerValoraciones();

  // Guardar la nueva valoración
  valoraciones.push(rating);
  fs.writeFileSync(valoracionesPath, JSON.stringify(valoraciones, null, 2));
  console.log("Valoración guardada:", rating);

  // Responder con éxito
  res.status(200).send({ message: "Valoración guardada con éxito." });
});

// Endpoint para obtener todas las valoraciones
app.get('/ratings', (req, res) => {
  const valoraciones = leerValoraciones();
  res.status(200).send(valoraciones);
});

// Crear servidor HTTPS
const server = https.createServer(options, app);

// Inicializar socket.io con el servidor HTTPS
const io = new Server(server);

// Manejar conexiones de socket.io
io.on('connection', (socket) => {
  console.log(`Usuario conectado: ${socket.id}`);

  // Manejo de eventos de registro y login
  socket.on('registro', ({ nombre, email, password }) => {
    console.log(">> Registro recibido:", nombre, email);
  
    const usuarios = leerUsuarios();
    console.log(">> Usuarios actuales:", usuarios);
  
    const yaExiste = usuarios.find(u => u.email === email);
  
    if (yaExiste) {
      console.log(">> Usuario ya existe");
      socket.emit('registroError', 'Ya existe una cuenta con ese correo.');
    } else {
      usuarios.push({ nombre, email, password });
      guardarUsuarios(usuarios);
      console.log(">> Usuario guardado:", { nombre, email });
      socket.emit('registroOk');
    }
  });
  
  socket.on('login', ({ email, password }) => {
    const usuarios = leerUsuarios();
    const usuario = usuarios.find(u => u.email === email && u.password === password);

    if (usuario) {
      socket.emit('loginOk', {usuario: usuario.nombre, email: usuario.email});
    } else {
      socket.emit('loginError', 'Correo o contraseña incorrectos.');
    }
  });

  // Manejo de eventos valoraciones
  socket.on('recv_rate', () => {
    const valoraciones = leerValoraciones();
    socket.emit('print_rate', valoraciones);
  });

  socket.on('new_rating', (data) => {
    let ratings = JSON.parse(fs.readFileSync(valoracionesPath))
    ratings.push(data);
    fs.writeFileSync(valoracionesPath, JSON.stringify(ratings, null, 2));
    socket.broadcast.emit('broadcast_rating');
  });

  socket.on('send_search', (data) => {
    console.log("Enviando");
    socket.broadcast.emit('ubicacion', data);
  });

  socket.on('ubi_find', (data) => {
    console.log("Recibiendo");
    socket.broadcast.emit('user_find', data);
  });

  socket.on('recv_incidence', () => {
    const incidencias = leerIncidencias();
    socket.emit('print_incidence', incidencias);
  });

  socket.on('upload_incidences', (data) => {
    // Guardar las incidencias en un archivo JSON
    fs.writeFileSync(incidenciasPath, JSON.stringify(data.incidencias, null, 2));
    let incidencia = `Incidencia emitida: ${data.mensaje}`;
    socket.broadcast.emit('broadcast_incidence', incidencia);
    console.log('Incidencias guardadas');

    // Enviar respuesta al cliente
    socket.emit('incidences_stored', 'Las incidencias se han guardado correctamente');
  });

  socket.on('disconnect', () => {
    console.log(`Usuario desconectado: ${socket.id}`);
  });

});

// Configurar el puerto y arrancar el servidor
const PORT = 3000; // Cambia el puerto según tus necesidades
server.listen(PORT, () => {
    console.log(`Servidor HTTPS corriendo en https://localhost:${PORT}`);
});

const usuariosPath = path.join('stores/usuarios.json');
const valoracionesPath = path.join('stores/valoraciones.json');
const incidenciasPath = path.join('stores/incidencias.json');

// Funciones para manejar usuarios
function leerUsuarios() {
  if (!fs.existsSync(usuariosPath)) {
    fs.writeFileSync(usuariosPath, '[]');
  }
  return JSON.parse(fs.readFileSync(usuariosPath));
}

function guardarUsuarios(usuarios) {
  fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));
}

function leerValoraciones() {
  if (!fs.existsSync(valoracionesPath)) {
    fs.writeFileSync(valoracionesPath, '[]');
  }
  return JSON.parse(fs.readFileSync(valoracionesPath));
}

function leerIncidencias() {
  if (!fs.existsSync(incidenciasPath)) {
    fs.writeFileSync(incidenciasPath, '[]');
  }

  let incidencias = JSON.parse(fs.readFileSync(incidenciasPath));
  const ahora = new Date();

  // Filtrar incidencias con diferencia de menos de 2 horas
  incidencias = incidencias.filter(incidencia => {
    const fecha = new Date(incidencia.fecha);
    const diffMs = Math.abs(ahora - fecha);
    const diffHoras = diffMs / (1000 * 60 * 60);
    return diffHoras < 2;
  });

  // Guardar las incidencias filtradas de nuevo
  fs.writeFileSync(incidenciasPath, JSON.stringify(incidencias, null, 2));

  return JSON.parse(fs.readFileSync(incidenciasPath));
}
