const socket = io(); // Conectar con el servidor usando Socket.IO

// Mostrar el formulario de inicio de sesión por defecto
function showTab(tabName) {
    document.getElementById("login").style.display = "none";
    document.getElementById("register").style.display = "none";
    document.getElementById("loginBtn").classList.remove("active");
    document.getElementById("registerBtn").classList.remove("active");

    document.getElementById(tabName).style.display = "block";

    if (tabName === 'login') {
        document.getElementById("loginBtn").classList.add("active");
    } else {
        document.getElementById("registerBtn").classList.add("active");
    }
    }
document.addEventListener('DOMContentLoaded', () => {

    // Evento para el formulario de registro
    document.getElementById('register-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const nombre = document.getElementById("register-name").value;
    const email = document.getElementById("register-email").value;
    const password = document.getElementById("register-password").value;

    socket.emit('registro', { nombre, email, password });
    });

    // Evento para el formulario de login
    document.getElementById('login-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const email = document.getElementById("login-email").value;
    const password = document.getElementById("login-password").value;

    socket.emit('login', { email, password });
    });

    // Escuchar respuesta del servidor para registro
    socket.on('registroOk', () => {
    alert("¡Registro exitoso! Ahora puedes iniciar sesión.");
    showTab('login');
    });

    socket.on('registroError', (mensaje) => {
    alert("Error al registrarse: " + mensaje);
    });

    // Escuchar respuesta del servidor para login
    socket.on('loginOk', ({usuario, email}) => {
        // Guardar datos en el localStorage
        localStorage.setItem("usuario", JSON.stringify({usuario, email}));
        // Redirigir a la app principal
        window.location.href = "/menu";
    });

    socket.on('loginError', (mensaje) => {
    alert("Error al iniciar sesión: " + mensaje);
    });
});