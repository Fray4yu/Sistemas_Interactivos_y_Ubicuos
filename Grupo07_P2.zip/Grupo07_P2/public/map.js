const socket = io();
const map = L.map('map').setView([40.4168, -3.7038], 6); // Vista inicial en Madrid

// Añadir capa de mapa base de OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Función para leer texto en voz alta
function speakText(html) {
  // Convertimos los <br> en espacios y extraemos texto plano
  const text = html.replace(/<br\s*\/?>/gi, ' ');
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'es-ES';
  speechSynthesis.speak(utterance);
}

// Constantes globales
const locations = {
  'madrid': [40.4168, -3.7038],
  'barcelona': [41.3851, 2.1734],
  'valencia': [39.4699, -0.3763],
  'sevilla': [37.3886, -5.9823],
  'zaragoza': [41.6488, -0.8891],
  'málaga': [36.7213, -4.4213],
  'murcia': [37.9922, -1.1307],
  'palma': [39.5696, 2.6502],
  'las palmas': [28.1235, -15.4363],
  'bilbao': [43.2630, -2.9340],
  'alicante': [38.3452, -0.4810],
  'córdoba': [37.8882, -4.7794],
  'valladolid': [41.6523, -4.7236],
  'vigo': [42.2406, -8.7207],
  'gijón': [43.5322, -5.6611],
  'granada': [37.1773, -3.5986],
  'oviedo': [43.3619, -5.8494],
  'santander': [43.4623, -3.8099],
  'majadahonda': [40.4785, -3.8667],
  'getafe': [40.3108, -3.7318],
  'cádiz': [36.5298, -6.2923]
};

// Marcadores
let userMarker = null;
let destinationMarker = null;

// Popups y capas
let errorPopup = null;
let routeLayer = null;

// Ubicacion destino y nombre
let lat = null;
let lon = null;
let ubicacion = null;

// Ubicacion usuario
let user = null;
// Ubicacion usuario a seguir
let ubi_seguir = null;

let ubicacionExiste = false;
let searchingUser = false;

const usuario = JSON.parse(localStorage.getItem("usuario"));
const popup = document.getElementById("mensaje");

// Función para calcular la distancia en kilómetros entre dos coordenadas
function getDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Radio de la Tierra en km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function printLocation(locationName){
  [lat, lon] = locations[locationName];

  if (user && lat && lon) {
    let distance = getDistance(user.coords.latitude, user.coords.longitude, lat, lon);
    console.log(`Distancia al destino: ${distance.toFixed(2)} km`);

    destinationMarker = L.marker([lat, lon]).addTo(map)
    .bindPopup(`${locationName.toUpperCase()} - Distancia: ${distance.toFixed(2)} km`, {
      closeButton: false,
    })
    .openPopup();

    let routeURL = `https://router.project-osrm.org/route/v1/driving/${user.coords.longitude},${user.coords.latitude};${lon},${lat}?overview=full&geometries=geojson`;
      
    fetch(routeURL)
      .then(response => response.json())
      .then(data => {
        let bounds = L.latLngBounds([[user.coords.latitude, user.coords.longitude], [lat, lon]]);
        map.fitBounds(bounds);

        let routeCoords = data.routes[0].geometry.coordinates.map(coord => [coord[1], coord[0]]);
        routeLayer = L.polyline(routeCoords, {color: 'blue', weight: 5}).addTo(map);
          
        let midLat = (user.coords.latitude + lat) / 2;
        let midLon = (user.coords.longitude + lon) / 2;

        map.setView([midLat, midLon]);
      })
      .catch(error => console.error('Error obteniendo la ruta:', error));
  }
}

// Escuchar palabras clave enviadas por el servidor
function getLocation(data) {
  if (errorPopup) {
    errorPopup = document.getElementById("errorPopup")
    errorPopup.style.opacity = "0";
    document.getElementById("errorPopup").style.display = "hidden";
    errorPopup = null;
  }
  if (routeLayer) {
    map.removeLayer(routeLayer);
  }
  if (destinationMarker) {
    map.removeLayer(destinationMarker);
  }
    
  let locationName = data.toLowerCase();
  console.log(locationName.toUpperCase());
  if (locations[locationName]) {
    ubicacionExiste = true;
    printLocation(locationName);
    ubicacion = locationName
    return false;
  }
  else {
    errorPopup = document.getElementById("errorPopup")
    document.getElementById("errorMessage").innerText = `${locationName.toUpperCase()} no reconocido. Inténtalo de nuevo.`;
    errorPopup.style.display = "flex";
    errorPopup.offsetHeight;
    errorPopup.style.opacity = "1";
    return true;
  }
}

// Obtener ubicación actual y verificar proximidad al destino
function checkUserLocation() {
  if ("geolocation" in navigator) {
    navigator.geolocation.getCurrentPosition(function(position) {
      if (userMarker) {
        map.removeLayer(userMarker);
      }
      if (ubicacionExiste) {
        const newDistance = getDistance(position.coords.latitude, position.coords.longitude, user.coords.latitude, user.coords.longitude);
        if (newDistance > 0) {
          if (routeLayer) {
            map.removeLayer(routeLayer);
            user = position;
          }
          printLocation(ubicacion);
        }
      }
      userMarker = L.marker([position.coords.latitude, position.coords.longitude]).addTo(map).openPopup();

      user = position;

      checkLocationTemp(user)
    })
  } else {
    console.error("Geolocalización no soportada en este navegador.");
  }
}

// Obtener temperatura de la ubicación actual
function checkLocationTemp(usuario) {
  const apiKey = "116f43de73503bccf3dd63b92cf6c8fe";
  const url = `https://api.openweathermap.org/data/2.5/weather?lat=${usuario.coords.latitude}&lon=${usuario.coords.longitude}&appid=${apiKey}&units=metric&lang=es`;

  fetch(url)
    .then(response => response.json())
    .then(data => {
      if (data.main) {
        let temp = data.main.temp;
        let description = data.weather[0].description;
        document.getElementById("temperature").textContent = `${temp}°C, ${description}`;
      } else {
          document.getElementById("temperature").textContent = "No se pudo obtener la temp."
      }

    })
    .catch(error => {
        console.error("Error obteniendo el clima:", error);
        document.getElementById("temperature").textContent = "Error obteniendo temp.";
  });
}

function checkTime() {
  const now = new Date();
  let hours = now.getHours();
  let minutes = now.getMinutes();

  // Añadir ceros a la izquierda si hace falta
  if (hours < 10) hours = "0" + hours;
  if (minutes < 10) minutes = "0" + minutes;

  const formattedTime = `${hours}:${minutes}`;
  document.getElementById("clock").textContent = `${formattedTime}`;
}

function getUser(data) {
  searchingUser = true;
  socket.emit('send_search', data);
}

socket.on('ubicacion', (data) => {
  console.log("Recibido");
  console.log(data);
  console.log(usuario.usuario);
  if (data.toLowerCase() === usuario.usuario.toLowerCase()) {
    socket.emit('ubi_find', user);
  }
});

socket.on('user_find', (data) => {
  if (searchingUser = true) {
    // Icono personalizado usuario a seguir
    const redIcon = L.icon({
      iconUrl: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png',
      iconSize: [36, 36],
      iconAnchor: [18, 36],
      popupAnchor: [0, -36]
    });
    ubi_seguir = L.marker([data.coords.latitude, data.coords.longitude], {icon: redIcon}).addTo(map).openPopup();
    map.setView([data.coords.latitude, data.coords.longitude], 14);
  }
});

if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = new SpeechRecognition();
  recognition.lang = 'es-ES';
  recognition.continuous = false; // Solo detecta una frase cada vez
  recognition.interimResults = false;

  let textoLectura = `Bienvenido, ${usuario.usuario}. <br> <br>
                      Di qué opción quieres escoger: <br>
                      RUTA 🛣️ <br>
                      VALORACIONES⭐<br>
                      INCIDENCIAS 🚧 <br>
                      SEGUIMIENTO 🧑 <br>
                      CERRAR SERSIÓN 🚪`;
  let esperandoDestino = false;
  let esperandoNombre = false;
  let destinoMarcado = false;
  let destinoError = false;
  let detectSomething = false;

  recognition.onresult = (event) => {
    detectSomething = true;
    const transcript = event.results[0][0].transcript.trim().toLowerCase();
    console.log("Texto detectado:", transcript);

    if (!esperandoDestino && transcript.includes("ruta")) {
      console.log("🔁 Activando escucha de destino...");
      esperandoDestino = true;
      textoLectura = `📍 Elige la ubicación a la que quieras ir.`;
      escucharOrden();
    } else if (esperandoDestino) {
      console.log("📍 Destino detectado:", transcript);
      destinoError = getLocation(transcript);
      if (destinoError) {
        setTimeout(() => {
          detectSomething = false;
          recognition.start();
          console.log("🎙️ Escuchando orden...");
        }, 4000);
      } else {
        esperandoDestino = false;
      }
    } else if (transcript.includes("valoraciones")) {
      textoLectura = `Entendido. <br> Abriendo VALORACIONES ⭐`;
      mostrarPopup(textoLectura);
      setTimeout(function() {
        window.location.href = "/ratings";
      }, 2000);
    } else if (transcript.includes("incidencias")) {
      textoLectura = `Entendido. <br> Abriendo INCIDENCIAS 🚧`;
      mostrarPopup(textoLectura);
      setTimeout(function() {
        window.location.href = "/incidences";
      }, 2000);
    } else if (!esperandoNombre && transcript.includes("seguimiento")) {
      console.log("🔁 Activando escucha de nombre...");
      esperandoNombre = true;
      textoLectura = `🧑 Elige el usuario que quieres buscar.`;
      escucharOrden();
    } else if (esperandoNombre) {
      ubi_seguir = null;
      getUser(transcript);
      setTimeout(() => {
        if (!ubi_seguir) {
          textoLectura = `Nombre no detectado o no encontrado.`;
          escucharOrden();
        } else {
          esperandoNombre = false;
        }
      }, 3000);
    } else if (transcript.includes("cerrar sesión")) {
      textoLectura = `Entendido. <br> CERRANDO SESIÓN 🚪`;
      mostrarPopup(textoLectura);
      setTimeout(function() {
        localStorage.removeItem('usuario');
        window.location.href = "/";
      }, 2000);
    } else {
      console.log("Palabra detectada no existente: ", transcript);
      textoLectura = `❌ Error al detectar la orden. <br>
                      Di qué opción quieres escoger: <br>
                      RUTA 🛣️ <br>
                      VALORACIONES⭐<br>
                      INCIDENCIAS 🚧 <br>
                      SEGUIMIENTO 🧑 <br>
                      CERRAR SERSIÓN 🚪`;
      escucharOrden();
    }
  };

  recognition.onerror = (event) => {
    console.error('❌ Error en reconocimiento de voz:', event.error);
    textoLectura = `❌ Error al detectar la orden. <br>
                    Di qué opción quieres escoger: <br>
                    RUTA 🛣️ <br>
                    VALORACIONES ⭐<br>
                    INCIDENCIAS 🚧 <br>
                    SEGUIMIENTO 🧑 <br>
                    CERRAR SERSIÓN 🚪`;
    escucharOrden();
  };

  recognition.onend = () => {
    if (!detectSomething) {
      if (esperandoDestino) {
        textoLectura = `❌ Repite la ubicación, por favor`;
      } else if (!esperandoDestino) {
        textoLectura = `❌ Error al detectar la orden. <br>
                        Di qué opción quieres escoger: <br>
                        RUTA 🛣️ <br>
                        VALORACIONES ⭐<br>
                        INCIDENCIAS 🚧 <br>
                        SEGUIMIENTO 🧑 <br>
                        CERRAR SERSIÓN 🚪`;
      }
      escucharOrden();
    }
  };

  function mostrarPopup(mensaje) {
    popup.innerHTML = mensaje;
    speakText(mensaje);  // ← Aquí se activa la lectura en voz alta
    setTimeout(() => {
      popup.classList.add('fadeInOutAnimation');
    }, 10);
    setTimeout(popup.classList.remove('fadeInOutAnimation'), 4000)
  }

  function escucharOrden() {
    if (textoLectura) {
      mostrarPopup(textoLectura);
      setTimeout(() => {
        recognition.start();
        console.log("🎙️ Escuchando orden...");
      }, 4000);
    } else {
      recognition.start();
      console.log("🎙️ Escuchando orden...");
    }
  }

  // Escuchar si sitio no seleccionado
  if (!destinoMarcado) {
    escucharOrden();
  }

} else {
  alert('El reconocimiento de voz no es compatible con este navegador.');
}

// Monitorear la ubicación del usuario y la hora cada segundo
setInterval(checkUserLocation, 100);
setInterval(checkTime, 1000);

// Función para verificar si el usuario ha llegado al destino
function checkArrival() {
  if (user && lat && lon) {
    const distance = getDistance(user.coords.latitude, user.coords.longitude, lat, lon);
    if (distance <= 0.1) { // Consideramos que ha llegado si está a menos de 100 metros
      console.log("📍 Usuario ha llegado al destino.");
      clearInterval(arrivalCheckInterval); // Detener la verificación de llegada
      showRatingPopup(); // Mostrar el pop-up para valoración
    }
  }
}

function mostrarAdvertencia(mensaje) {
  popup.innerHTML = mensaje;
  speakText(mensaje);
  setTimeout(() => {
    popup.classList.add('fadeInOutAnimation');
  }, 10);
  setTimeout(popup.classList.remove('fadeInOutAnimation'), 2000)
}

socket.on('broadcast_rating', () => {
  mostrarAdvertencia("Valoración añadida");
});

socket.on('broadcast_incidence', (data) => {
  mostrarAdvertencia(data);
});

// Mostrar pop-up para preguntar si desea hacer una valoración
function showRatingPopup() {
  const ratingPopup = document.createElement('div');
  ratingPopup.id = 'ratingPopup';
  ratingPopup.style.position = 'fixed';
  ratingPopup.style.top = '50%';
  ratingPopup.style.left = '50%';
  ratingPopup.style.transform = 'translate(-50%, -50%)';
  ratingPopup.style.padding = '20px';
  ratingPopup.style.border = "3px solid black";
  ratingPopup.style.backgroundColor = "rgba(65, 62, 95, 0.95)";
  ratingPopup.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
  ratingPopup.style.borderRadius = "30px";
  ratingPopup.style.zIndex = '1000';
  ratingPopup.style.display = 'flex';
  ratingPopup.style.flexDirection = 'column';
  ratingPopup.style.justifyContent = 'space-between';
  ratingPopup.style.height = '100px'; 
  ratingPopup.innerHTML = `
    <p style="color: rgb(255, 254, 170);">¿Deseas hacer una valoración de tu experiencia?</p>
    <div id="buttonsContainer" style="display: flex; justify-content: center; margin-top: auto;">
      <button id="yesButton" style="margin-right: 10px; padding: 10px; background-color: #29d504; color: white; border: none; cursor: pointer;">Sí</button>
      <button id="noButton" style="padding: 10px; background-color: #DC3545; color: white; border: none; cursor: pointer;">No</button>
    </div>
  `;
  document.body.appendChild(ratingPopup);

  document.getElementById('yesButton').addEventListener('click', () => {
    document.body.removeChild(ratingPopup);
    startStarRating(); // Iniciar el proceso de valoración con estrellas
  });

  document.getElementById('noButton').addEventListener('click', () => {
    document.body.removeChild(ratingPopup);
    console.log("El usuario decidió no hacer una valoración.");
    textoLectura = `Gracias por confiar en nuestra aplicación.`;
    mostrarPopup(textoLectura);
    setTimeout(function() {
      window.location.href = "/menu";
    }, 3000);
  });
}

// Mostrar pop-up para valorar con estrellas
function startStarRating() {
  const ratingPopup = document.createElement('div');
  ratingPopup.id = 'ratingPopup';
  ratingPopup.style.position = 'fixed';
  ratingPopup.style.top = '50%';
  ratingPopup.style.left = '50%';
  ratingPopup.style.transform = 'translate(-50%, -50%)';
  ratingPopup.style.padding = '20px';
  ratingPopup.style.border = "3px solid black";
  ratingPopup.style.backgroundColor = "rgba(65, 62, 95, 0.95)";
  ratingPopup.style.borderRadius = "30px";
  ratingPopup.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
  ratingPopup.style.zIndex = '1000';
  ratingPopup.style.display = 'flex';
  ratingPopup.style.flexDirection = 'column';
  ratingPopup.style.justifyContent = 'space-between';
  ratingPopup.style.height = '225px';  
  
  ratingPopup.innerHTML = `
    <p style="color: rgb(255, 254, 170);">Por favor, selecciona el número de estrellas para valorar tu experiencia:</p>
    <div id="starsContainer" style="display: flex; justify-content: center; gap: 10px; cursor: pointer; color: #fcf809;">
      ${[1, 2, 3, 4, 5].map(star => `<span class="star" data-value="${star}" style="font-size: 2rem;">☆</span>`).join('')}
    </div>
    <textarea id="commentBox" placeholder="Añade un comentario (opcional)" style="width: 100%; margin-top: 10px; padding: 5px;"></textarea>
    <div id="submitContainer" style="display: flex; justify-content: center; margin-top: auto;">
      <button id="submitRating" style="padding: 10px; background-color: #29d504; color: white; border: none; cursor: pointer;">Enviar</button>
    </div>
  `;
  document.body.appendChild(ratingPopup);

  const stars = document.querySelectorAll('.star');
  let selectedStars = 0;

  // Evento para seleccionar estrellas
  stars.forEach(star => {
    star.addEventListener('click', (e) => {
      selectedStars = parseInt(e.target.getAttribute('data-value'));
      stars.forEach(s => s.textContent = '☆'); // Resetear todas las estrellas
      for (let i = 0; i < selectedStars; i++) {
        stars[i].textContent = '★'; // Marcar las estrellas seleccionadas
      }
    });
  });

  // Evento para enviar la valoración
  document.getElementById('submitRating').addEventListener('click', () => {
    if (selectedStars === 0) {
      alert('Por favor, selecciona al menos una estrella.');
      return;
    }

    const comment = document.getElementById('commentBox').value;
    saveRating(selectedStars, comment);
    document.body.removeChild(ratingPopup);
    textoLectura = `Gracias por su valoración.`;
    mostrarPopup(textoLectura);
    setTimeout(function() {
      window.location.href = "/menu";
    }, 3000);
  });
}

// Guardar la valoración en /ratings
function saveRating(stars, comment) {
  const rating = {
    usuario: usuario.usuario,
    estrellas: stars,
    comentario: comment || "Sin comentario",
    fecha: new Date().toISOString() // Usar formato ISO para consistencia
  };

  console.log("Nueva valoración:", rating);
  // Emitir la valoración al servidor
  socket.emit('new_rating', rating);
}

// Iniciar la verificación de llegada al destino cada segundo
let arrivalCheckInterval = setInterval(checkArrival, 1000);
