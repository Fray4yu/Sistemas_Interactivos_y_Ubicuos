const socket = io();

const usuario = JSON.parse(localStorage.getItem("usuario"));

const closeButton = document.getElementById('closeButton');
const addIncidence = document.getElementById('addIncidence');
const sendIncidence = document.getElementById('sendIncidence');

let ubication = {
  lat: null,
  lon: null
};

window.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    socket.emit('recv_incidence');
  }, 100);
});

// Obtener ubicación actual
function checkUserLocation() {
  if ("geolocation" in navigator) {
    navigator.geolocation.getCurrentPosition(function(position){
      ubication.lat = position.coords.latitude
      ubication.lon = position.coords.longitude
    })
  } else {
    console.error("Geolocalización no soportada en este navegador.");
  }
}

// Monitorear la ubicación del usuario
setInterval(checkUserLocation, 1000);

// Funciones para manejar valoraciones
function printIncidencias(data) {
  // Ordenar por fecha descendente
  data.sort((a, b) => new Date(b.fecha) - new Date(a.fecha));

  // Mostrar en la interfaz
  const container = document.getElementById("incidences");
  container.innerHTML = ""; // Limpiar antes de insertar

  data.forEach(v => {
    const div = document.createElement("div");
    div.className = "incidence";
  
    // Establecer el color de fondo según la incidencia
    let color = "";
    if (v.incidencia === "Tráfico") {
      color = "#FF5722"; // naranja
      emoji = "🚗";
    } else if (v.incidencia === "Tráfico Alto") {
      color = "#D32F2F"; // rojo
      emoji = "🚗🚗🚗";
    } else if (v.incidencia === "Accidente") {
      color = "#FFEB3B"; // amarillo
      emoji = "⚠️";
    } else if (v.incidencia === "Carretera Cortada") {
      color = "#8D6E63"; //marrón
      emoji = "🚧";
    } else if (v.incidencia === "Policía") {
        color = "#1976D2"; //marrón
        emoji = "👮";
    }
  
    div.style.backgroundColor = color;
  
    div.innerHTML = `
      <strong>Usuario:</strong> ${v.usuario}<br>
      <strong>Incidencia:</strong> ${v.incidencia} ${emoji}<br>
      <strong>Hora:</strong> <em>${new Date(v.fecha).toLocaleTimeString(
        'es-ES', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }
      )}</em><br>
      <strong>Ubicación:</strong> [${v.ubicacion.lat}, ${v.ubicacion.lon}]<br>
    `;
    container.appendChild(div);
  });
}

closeButton.addEventListener('click', function() {
  sessionStorage.removeItem("incidencias");
  window.location.href = '/menu'; // Retornar a la interfaz principal
});

addIncidence.addEventListener('click', function() {
  document.getElementById("addIncidence").style.display = "none";
  document.getElementById("formIncidence").style.display = "block";
});

sendIncidence.addEventListener('click', function() {
  let incidencia = document.getElementById("tipoIncidencia").value;

  if (!usuario || !incidencia) {
    alert("Por favor, completa todos los campos.");
    return;
  }

  let nuevaIncidencia = {
    usuario: usuario.usuario,
    incidencia: incidencia,
    fecha: new Date().toISOString(),
    ubicacion: ubication
  };

  const incidencias = JSON.parse(sessionStorage.getItem("incidencias") || "[]");
  incidencias.push(nuevaIncidencia);

  socket.emit('upload_incidences', { incidencias: incidencias, mensaje: incidencia});

  socket.on('incidences_stored', (data) => {
    console.log(data);
    window.location.href = '/incidences'; // Refrescar página
  });
});

socket.on('print_incidence', (data) => {
  sessionStorage.setItem("incidencias", JSON.stringify(data));
  printIncidencias(data);
});