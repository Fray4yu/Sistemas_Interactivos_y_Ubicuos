const socket = io();

const closeButton = document.getElementById('closeButton');

let user = {
  lat: null,
  lon: null
};

window.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    socket.emit('recv_rate');
  }, 100);
});

// Obtener ubicación actual
function checkUserLocation() {
  if ("geolocation" in navigator) {
    navigator.geolocation.getCurrentPosition(function(position){
      user.lat = position.coords.latitude
      user.lon = position.coords.longitude
    })
  } else {
    console.error("Geolocalización no soportada en este navegador.");
  }
}

// Monitorear la ubicación del usuario
setInterval(checkUserLocation, 1000);

// Funciones para manejar valoraciones
function printValoraciones(data) {
  // Ordenar por fecha descendente
  data.sort((a, b) => new Date(b.fecha) - new Date(a.fecha));

  // Mostrar en la interfaz
  const container = document.getElementById("ratings");
  container.innerHTML = ""; // Limpiar antes de insertar

  data.forEach(v => {
    const div = document.createElement("div");
    div.className = "rating";
    div.innerHTML = `
      <strong>${v.usuario}</strong> - Valor: ${v.estrellas} ⭐<br>
      <em>${new Date(v.fecha).toLocaleString()}</em><br>
      <p>${v.comentario}</p>
    `;
    container.appendChild(div);
  });
}

closeButton.addEventListener('click', function() {
  sessionStorage.removeItem("valoraciones");
  window.location.href = '/menu'; // Retornar a la interfaz principal
});

socket.on('print_rate', (data) => {
  sessionStorage.setItem("valoraciones", JSON.stringify(data));
  printValoraciones(data);
});